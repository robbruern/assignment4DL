import torch
import torch.nn as nn
import torch.nn.functional as F
from gan.spectral_normalization import SpectralNorm

class Discriminator(torch.nn.Module):
    def __init__(self, input_channels=3):
        super().__init__()
        self.testConv = nn.Conv2d(3, 128, 4, stride = 2, padding=1)
        self.conv1 = SpectralNorm(nn.Conv2d(3, 128, 4, stride = 2, padding=1))
        self.conv2 = SpectralNorm(nn.Conv2d(128, 256, 4, stride = 2, padding=1))
        self.conv3 = SpectralNorm(nn.Conv2d(256, 512, 4, stride = 2, padding=1))
        self.conv4 = SpectralNorm(nn.Conv2d(512, 1024, 4, stride = 2, padding=1))
        self.conv5 = SpectralNorm(nn.Conv2d(1024, 1, 4, stride = 1, padding=1))
        #self.conv5 = nn.Conv2d(256, 256, 3)
        self.bnorm512 = nn.BatchNorm2d(512)
        self.bnorm256 = nn.BatchNorm2d(256)
        self.bnorm1024 = nn.BatchNorm2d(1024)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2)
        self.fc = nn.Linear(128 * 1 *3 * 3, 128)
        
        #Hint: Hint: Apply spectral normalization to convolutional layers. Input to SpectralNorm should be your conv nn module
        ####################################
        #          YOUR CODE HERE          #
        ####################################
        
        
        ##########       END      ##########
    
    def forward(self, x):
        #print("Begin Descrimantor X size: ", x)
        
        x = self.lrelu(self.conv1(x))
        #print("DPost 1st conv: ", x)
        x = (self.conv2(x))
        #print("DPost 2st conv: ", x.size())
        x = self.bnorm256(x)
        x = self.lrelu(x)
        x = (self.conv3(x))
        #print("DPost 3st conv: ", x.size())
        x = self.bnorm512(x)
        x = self.lrelu(x)
        x = (self.conv4(x))
        #print("DPost 4st conv: ", x.size())
        x = self.bnorm1024(x)
        x = self.lrelu(x)
        x = self.lrelu(self.conv5(x))
        #print("DPost 5st conv: ", x.size())
        x = x.view(128* 3 * 3)
        #print(x.size())
        x = self.lrelu(self.fc(x))
        #print("DPost fc: ", x.size())
        ####################################
        #          YOUR CODE HERE          #
        ####################################
        
        
        ##########       END      ##########
        
        return x


class Generator(torch.nn.Module):
    def __init__(self, noise_dim, output_channels=3):
        super().__init__()    
        self.noise_dim = noise_dim
        self.conv1 = nn.ConvTranspose2d(noise_dim, 1024, 4, stride = 1, padding=0)
        self.conv2 = nn.ConvTranspose2d(1024, 512, 4, stride = 2, padding=1)
        self.conv3 = nn.ConvTranspose2d(512, 256, 4, stride = 2, padding=1)
        self.conv4 = nn.ConvTranspose2d(256, 128, 4, stride = 2, padding=1)
        self.conv5 = nn.ConvTranspose2d(128, 3, 4, stride = 2, padding=1)
        #self.conv5 = nn.Conv2d(256, 256, 3)
        self.bnorm512 = nn.BatchNorm2d(512)
        self.bnorm256 = nn.BatchNorm2d(256)
        self.bnorm128 = nn.BatchNorm2d(128)
        self.bnorm1024 = nn.BatchNorm2d(1024)

        ####################################
        #          YOUR CODE HERE          #
        ####################################
        
        
        ##########       END      ##########
    
    def forward(self, x):
        x = x[:,:,None,None]
        #print("Begin Generator X size: ", x.size())
        x = F.relu(self.conv1(x))
        #print("GPost 1st conv: ", x.size())
        x = self.bnorm1024(x)
        x = F.relu(self.conv2(x))
        #print("GPost 2st conv: ", x.size())
        x = self.bnorm512(x)
        x = F.relu(self.conv3(x))
        #print("GPost 3st conv: ", x.size())
        x = self.bnorm256(x)
        x = F.relu(self.conv4(x))
        #print("GPost 4st conv: ", x.size())
        x = self.bnorm128(x)
        x = F.relu(self.conv5(x))
        #print("GPost 5st conv: ", x.size())
        ####################################
        #          YOUR CODE HERE          #
        ####################################
        
        
        ##########       END      ##########
        
        return (x)
    

